The program will run only if you give "1" IN THE FIRST COLUMN, ONLY ONCE!
If you give "1" more than once and/or not in the first column, it will show solution 
doesn't exist even if it does!
It sucks; but deal with it!