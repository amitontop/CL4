import json
import os

def printboard(board):
	for i in range(8):
		for j in range(8):
			print(str(board[i][j]))+" ",
		print "\n"
		

inf=open("ip.json")
board=json.loads(inf.read())
board=board["matrix"]
print "Input : "
printboard(board)

def issafe2(row,col):
	for i in range(8):
		for j in range(8):
			if(board[i][j]==1):
				if(row==i):
					return False
				if(col==j):
					return False
				if(abs(row-i)==abs(col-j)):
					return False

	return True

def place2(col):
	if(col>=8):
		return True
	for i in range(8):
		if(issafe2(i,col)):
			board[i][col]=1
			if(place2(col+1)==True):
				return True
			board[i][col]=0
	return False


if(place2(1)==True):
	print("Solution Found : ")
else:
	print("Solution not posible")

printboard(board)




"""

OUTPUT:

pinakinparkhe@ubuntu:~$ gedit b1.py
pinakinparkhe@ubuntu:~$ python b1.py
Input : 
0  0  0  0  0  0  0  0  

0  0  0  0  0  0  0  0  

0  0  0  0  0  0  0  0  

1  0  0  0  0  0  0  0  

0  0  0  0  0  0  0  0  

0  0  0  0  0  0  0  0  

0  0  0  0  0  0  0  0  

0  0  0  0  0  0  0  0  

Solution Found : 
0  1  0  0  0  0  0  0  

0  0  0  0  1  0  0  0  

0  0  0  0  0  0  1  0  

1  0  0  0  0  0  0  0  

0  0  1  0  0  0  0  0  

0  0  0  0  0  0  0  1  

0  0  0  0  0  1  0  0  

0  0  0  1  0  0  0  0  

pinakinparkhe@ubuntu:~$ 

"""	
