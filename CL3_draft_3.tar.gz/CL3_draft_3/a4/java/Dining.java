import com.mongodb.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Dining {

public static void main(String[] args) {
    Lock forks[] = new ReentrantLock[5];
    
    try {
		MongoClient mongoClient = new MongoClient("localhost");
		System.out.println("Connection to mongodb successful.");
		DB db = mongoClient.getDB( "mydb" );
		System.out.println("Database 'mydb' created.");
		DBCollection coll = db.createCollection("mycol", null);
		System.out.println("Collection 'mycol' created.");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
   for(int i = 0; i<5; i++){
        forks[i] = new ReentrantLock(); 
    }

    Thread p1 = new Thread(new Philosopher(forks[4], forks[0], "first"));
    Thread p2 = new Thread(new Philosopher(forks[0], forks[1], "second"));
    Thread p3 = new Thread(new Philosopher(forks[1], forks[2], "third"));
    Thread p4 = new Thread(new Philosopher(forks[2], forks[3], "fourth"));
    Thread p5 = new Thread(new Philosopher(forks[3], forks[4], "fifth"));

    p1.start();
    p2.start();
    p3.start();
    p4.start();
    p5.start(); 


}
}

class Philosopher implements Runnable {
Lock leftFork = new ReentrantLock();
Lock rightFork = new ReentrantLock();
String name;


public Philosopher(Lock leftFork, Lock rightFork, String name) {
    this.leftFork = leftFork;
    this.rightFork = rightFork;
    this.name = name; 
}

@Override
public void run() {
	try {
    think(name);
	eat(leftFork, rightFork, name); 
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

private void eat(Lock leftFork, Lock rightFork, String name) throws Exception{
    leftFork.lock();
    rightFork.lock();
    try
    {
    MongoClient mongoClient = new MongoClient("localhost");
    DB db = mongoClient.getDB( "mydb" );
    DBCollection coll = db.getCollection("mycol");

    System.out.println(name + " eating...");
    BasicDBObject doc1 = new BasicDBObject(name , " eating...");
    coll.insert(doc1);

        Thread.sleep(1000);
    } catch (Exception e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    } 
    finally{
        System.out.println(name + " done eating and now thinking...");
        MongoClient mongoClient = new MongoClient("localhost");
        DB db = mongoClient.getDB( "mydb" );
		DBCollection coll = db.getCollection("mycol");
		BasicDBObject doc2 = new BasicDBObject(name , " done eating and now thinking...");
		coll.insert(doc2);
        leftFork.unlock();
        rightFork.unlock(); 
    }
}

public void think(String name) throws Exception{
	try
    {
    MongoClient mongoClient = new MongoClient("localhost");
    DB db = mongoClient.getDB( "mydb" );
    DBCollection coll = db.getCollection("mycol");
    System.out.println(name + " thinking...");
    BasicDBObject doc = new BasicDBObject(name , " thinking...");
    coll.insert(doc);
        Thread.sleep(1000);
    } catch (InterruptedException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    } 
}

}



/*

OUTPUT:

ECLIPSE OUTPUT:

Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
Connection to mongodb successful.
Database 'mydb' created.
Collection 'mycol' created.
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
first thinking...
third thinking...
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
second thinking...
fourth thinking...
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
fifth thinking...
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:2, serverValue:3}] to localhost:27017
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:6, serverValue:7}] to localhost:27017
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:5, serverValue:6}] to localhost:27017
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:1, serverValue:2}] to localhost:27017
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:3, serverValue:4}] to localhost:27017
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=3088951}
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=2013400}
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:4, serverValue:5}] to localhost:27017
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=3526015}
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=1872274}
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=2426942}
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=6551246}
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:11, serverValue:9}] to localhost:27017
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:7, serverValue:8}] to localhost:27017
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:8, serverValue:10}] to localhost:27017
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:10, serverValue:11}] to localhost:27017
Jun 07, 2018 1:27:54 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:9, serverValue:12}] to localhost:27017
Jun 07, 2018 1:27:55 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
second eating...
Jun 07, 2018 1:27:56 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:27:56 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:12, serverValue:13}] to localhost:27017
Jun 07, 2018 1:27:56 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=1673841}
Jun 07, 2018 1:27:56 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:13, serverValue:14}] to localhost:27017
second done eating and now thinking...
Jun 07, 2018 1:27:57 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
Jun 07, 2018 1:27:57 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:27:57 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:14, serverValue:15}] to localhost:27017
Jun 07, 2018 1:27:57 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=1034069}
Jun 07, 2018 1:27:57 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:15, serverValue:16}] to localhost:27017
Jun 07, 2018 1:27:57 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
first eating...
Jun 07, 2018 1:27:57 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:27:57 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:16, serverValue:17}] to localhost:27017
Jun 07, 2018 1:27:57 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=736422}
Jun 07, 2018 1:27:57 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:17, serverValue:18}] to localhost:27017
first done eating and now thinking...
Jun 07, 2018 1:27:58 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
Jun 07, 2018 1:27:58 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:27:58 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:18, serverValue:19}] to localhost:27017
Jun 07, 2018 1:27:58 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=1083677}
Jun 07, 2018 1:27:58 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:19, serverValue:20}] to localhost:27017
Jun 07, 2018 1:27:58 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
fifth eating...
Jun 07, 2018 1:27:58 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:27:58 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:20, serverValue:21}] to localhost:27017
Jun 07, 2018 1:27:58 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=447327}
Jun 07, 2018 1:27:58 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:21, serverValue:22}] to localhost:27017
fifth done eating and now thinking...
Jun 07, 2018 1:27:59 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
Jun 07, 2018 1:27:59 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:27:59 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:22, serverValue:23}] to localhost:27017
Jun 07, 2018 1:27:59 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=1309052}
Jun 07, 2018 1:27:59 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:23, serverValue:24}] to localhost:27017
Jun 07, 2018 1:27:59 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
fourth eating...
Jun 07, 2018 1:27:59 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:27:59 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:24, serverValue:25}] to localhost:27017
Jun 07, 2018 1:27:59 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=463578}
Jun 07, 2018 1:27:59 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:25, serverValue:26}] to localhost:27017
fourth done eating and now thinking...
Jun 07, 2018 1:28:00 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
Jun 07, 2018 1:28:00 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:28:00 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:26, serverValue:27}] to localhost:27017
Jun 07, 2018 1:28:00 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=1031076}
Jun 07, 2018 1:28:00 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:27, serverValue:28}] to localhost:27017
Jun 07, 2018 1:28:00 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
third eating...
Jun 07, 2018 1:28:00 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:28:00 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:28, serverValue:29}] to localhost:27017
Jun 07, 2018 1:28:00 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=399858}
Jun 07, 2018 1:28:00 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:29, serverValue:30}] to localhost:27017
third done eating and now thinking...
Jun 07, 2018 1:28:01 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Cluster created with settings {hosts=[localhost:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}
Jun 07, 2018 1:28:01 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: No server chosen by WritableServerSelector from cluster description ClusterDescription{type=UNKNOWN, connectionMode=SINGLE, serverDescriptions=[ServerDescription{address=localhost:27017, type=UNKNOWN, state=CONNECTING}]}. Waiting for 30000 ms before timing out
Jun 07, 2018 1:28:01 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:30, serverValue:31}] to localhost:27017
Jun 07, 2018 1:28:01 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Monitor thread successfully connected to server with description ServerDescription{address=localhost:27017, type=STANDALONE, state=CONNECTED, ok=true, version=ServerVersion{versionList=[2, 6, 3]}, minWireVersion=0, maxWireVersion=2, maxDocumentSize=16777216, roundTripTimeNanos=677405}
Jun 07, 2018 1:28:01 AM com.mongodb.diagnostics.logging.JULLogger log
INFO: Opened connection [connectionId{localValue:31, serverValue:32}] to localhost:27017

MONGODB SERVER:

Microsoft Windows [Version 10.0.17134.48]
(c) 2018 Microsoft Corporation. All rights reserved.

C:\Users\Pinakin Parkhe>mongod
'mongod' is not recognized as an internal or external command,
operable program or batch file.

C:\Users\Pinakin Parkhe>mongo
'mongo' is not recognized as an internal or external command,
operable program or batch file.

C:\Users\Pinakin Parkhe>"C:\mongodb\mongodb-win\bin\mongod.exe" --version
db version v2.6.3
2018-06-07T01:19:29.945+0530 git version: 255f67a66f9603c59380b2a389e386910bbb52cb

C:\Users\Pinakin Parkhe>"C:\mongodb\mongodb-win\bin\mongod.exe" --dbpath E:\pinakin_be\sem_8\subs_be\cl3\oxy_ws\mongo_ws
2018-06-07T01:23:42.930+0530 [initandlisten] MongoDB starting : pid=5844 port=27017 dbpath=E:\pinakin_be\sem_8\subs_be\cl3\oxy_ws\mongo_ws 64-bit host=Lenovo-PC
2018-06-07T01:23:42.935+0530 [initandlisten] targetMinOS: Windows 7/Windows Server 2008 R2
2018-06-07T01:23:42.936+0530 [initandlisten] db version v2.6.3
2018-06-07T01:23:42.936+0530 [initandlisten] git version: 255f67a66f9603c59380b2a389e386910bbb52cb
2018-06-07T01:23:42.937+0530 [initandlisten] build info: windows sys.getwindowsversion(major=6, minor=1, build=7601, platform=2, service_pack='Service Pack 1') BOOST_LIB_VERSION=1_49
2018-06-07T01:23:42.938+0530 [initandlisten] allocator: system
2018-06-07T01:23:42.939+0530 [initandlisten] options: { storage: { dbPath: "E:\pinakin_be\sem_8\subs_be\cl3\oxy_ws\mongo_ws" } }
2018-06-07T01:23:43.010+0530 [initandlisten] journal dir=E:\pinakin_be\sem_8\subs_be\cl3\oxy_ws\mongo_ws\journal
2018-06-07T01:23:43.013+0530 [initandlisten] recover : no journal files present, no recovery needed
2018-06-07T01:23:43.106+0530 [FileAllocator] allocating new datafile E:\pinakin_be\sem_8\subs_be\cl3\oxy_ws\mongo_ws\local.ns, filling with zeroes...
2018-06-07T01:23:43.106+0530 [FileAllocator] creating directory E:\pinakin_be\sem_8\subs_be\cl3\oxy_ws\mongo_ws\_tmp
2018-06-07T01:23:43.127+0530 [FileAllocator] done allocating datafile E:\pinakin_be\sem_8\subs_be\cl3\oxy_ws\mongo_ws\local.ns, size: 16MB,  took 0.018 secs
2018-06-07T01:23:43.134+0530 [FileAllocator] allocating new datafile E:\pinakin_be\sem_8\subs_be\cl3\oxy_ws\mongo_ws\local.0, filling with zeroes...
2018-06-07T01:23:43.147+0530 [FileAllocator] done allocating datafile E:\pinakin_be\sem_8\subs_be\cl3\oxy_ws\mongo_ws\local.0, size: 64MB,  took 0.011 secs
2018-06-07T01:23:43.151+0530 [initandlisten] build index on: local.startup_log properties: { v: 1, key: { _id: 1 }, name: "_id_", ns: "local.startup_log" }
2018-06-07T01:23:43.151+0530 [initandlisten]     added index to empty collection
2018-06-07T01:23:43.152+0530 [initandlisten] waiting for connections on port 27017
2018-06-07T01:24:43.112+0530 [clientcursormon] mem (MB) res:37 virt:4404
2018-06-07T01:24:43.112+0530 [clientcursormon]  mapped (incl journal view):160
2018-06-07T01:24:43.118+0530 [clientcursormon]  connections:0
2018-06-07T01:24:43.638+0530 [TTLMonitor] query local.system.indexes query: { expireAfterSeconds: { $exists: true } } planSummary: COLLSCAN ntoreturn:0 ntoskip:0 nscanned:1 nscannedObjects:1 keyUpdates:0 numYields:1 locks(micros) r:578615 nreturned:0 reslen:20 469ms
2018-06-07T01:25:49.715+0530 [initandlisten] connection accepted from 127.0.0.1:65352 #1 (1 connection now open)
2018-06-07T01:27:54.567+0530 [initandlisten] connection accepted from 127.0.0.1:49250 #2 (2 connections now open)
2018-06-07T01:27:54.583+0530 [initandlisten] connection accepted from 127.0.0.1:49251 #3 (3 connections now open)
2018-06-07T01:27:54.585+0530 [initandlisten] connection accepted from 127.0.0.1:49252 #4 (4 connections now open)
2018-06-07T01:27:54.595+0530 [initandlisten] connection accepted from 127.0.0.1:49253 #5 (5 connections now open)
2018-06-07T01:27:54.598+0530 [initandlisten] connection accepted from 127.0.0.1:49254 #6 (6 connections now open)
2018-06-07T01:27:54.598+0530 [initandlisten] connection accepted from 127.0.0.1:49255 #7 (7 connections now open)
2018-06-07T01:27:54.757+0530 [initandlisten] connection accepted from 127.0.0.1:49258 #8 (8 connections now open)
2018-06-07T01:27:54.758+0530 [initandlisten] connection accepted from 127.0.0.1:49259 #9 (9 connections now open)
2018-06-07T01:27:54.758+0530 [initandlisten] connection accepted from 127.0.0.1:49260 #10 (10 connections now open)
2018-06-07T01:27:54.759+0530 [initandlisten] connection accepted from 127.0.0.1:49261 #11 (11 connections now open)
2018-06-07T01:27:54.780+0530 [initandlisten] connection accepted from 127.0.0.1:49262 #12 (12 connections now open)
2018-06-07T01:27:54.881+0530 [FileAllocator] allocating new datafile E:\pinakin_be\sem_8\subs_be\cl3\oxy_ws\mongo_ws\mydb.ns, filling with zeroes...
2018-06-07T01:27:54.901+0530 [FileAllocator] done allocating datafile E:\pinakin_be\sem_8\subs_be\cl3\oxy_ws\mongo_ws\mydb.ns, size: 16MB,  took 0.018 secs
2018-06-07T01:27:54.906+0530 [FileAllocator] allocating new datafile E:\pinakin_be\sem_8\subs_be\cl3\oxy_ws\mongo_ws\mydb.0, filling with zeroes...
2018-06-07T01:27:54.927+0530 [FileAllocator] done allocating datafile E:\pinakin_be\sem_8\subs_be\cl3\oxy_ws\mongo_ws\mydb.0, size: 64MB,  took 0.02 secs
2018-06-07T01:27:54.932+0530 [conn11] build index on: mydb.mycol properties: { v: 1, key: { _id: 1 }, name: "_id_", ns: "mydb.mycol" }
2018-06-07T01:27:54.932+0530 [conn11]    added index to empty collection
2018-06-07T01:27:54.978+0530 [conn12] command mydb.$cmd command: insert { insert: "mycol", ordered: true, documents: [ { _id: ObjectId('5b183cc281613112904ae29e'), first: " thinking..." } ] } keyUpdates:0 numYields:0 locks(micros) w:5 reslen:40 169ms
2018-06-07T01:27:54.978+0530 [conn9] command mydb.$cmd command: insert { insert: "mycol", ordered: true, documents: [ { _id: ObjectId('5b183cc281613112904ae29d'), third: " thinking..." } ] } keyUpdates:0 numYields:0 locks(micros) w:5 reslen:40 169ms
2018-06-07T01:27:54.978+0530 [conn11] command mydb.$cmd command: insert { insert: "mycol", ordered: true, documents: [ { _id: ObjectId('5b183cc281613112904ae2a3'), fifth: " thinking..." } ] } keyUpdates:0 numYields:0 locks(micros) w:8 reslen:40 169ms
2018-06-07T01:27:54.978+0530 [conn8] command mydb.$cmd command: insert { insert: "mycol", ordered: true, documents: [ { _id: ObjectId('5b183cc281613112904ae2a2'), fourth: " thinking..." } ] } keyUpdates:0 numYields:0 locks(micros) w:5 reslen:40 169ms
2018-06-07T01:27:54.978+0530 [conn10] command mydb.$cmd command: insert { insert: "mycol", ordered: true, documents: [ { _id: ObjectId('5b183cc281613112904ae2a1'), second: " thinking..." } ] } keyUpdates:0 numYields:0 locks(micros) w:5 reslen:40 169ms
2018-06-07T01:27:56.002+0530 [initandlisten] connection accepted from 127.0.0.1:49268 #13 (13 connections now open)
2018-06-07T01:27:56.016+0530 [initandlisten] connection accepted from 127.0.0.1:49269 #14 (14 connections now open)
2018-06-07T01:27:57.030+0530 [initandlisten] connection accepted from 127.0.0.1:49271 #15 (15 connections now open)
2018-06-07T01:27:57.040+0530 [initandlisten] connection accepted from 127.0.0.1:49272 #16 (16 connections now open)
2018-06-07T01:27:57.057+0530 [initandlisten] connection accepted from 127.0.0.1:49273 #17 (17 connections now open)
2018-06-07T01:27:57.067+0530 [initandlisten] connection accepted from 127.0.0.1:49274 #18 (18 connections now open)
2018-06-07T01:27:58.080+0530 [initandlisten] connection accepted from 127.0.0.1:49276 #19 (19 connections now open)
2018-06-07T01:27:58.092+0530 [initandlisten] connection accepted from 127.0.0.1:49277 #20 (20 connections now open)
2018-06-07T01:27:58.110+0530 [initandlisten] connection accepted from 127.0.0.1:49278 #21 (21 connections now open)
2018-06-07T01:27:58.136+0530 [initandlisten] connection accepted from 127.0.0.1:49279 #22 (22 connections now open)
2018-06-07T01:27:59.148+0530 [initandlisten] connection accepted from 127.0.0.1:49281 #23 (23 connections now open)
2018-06-07T01:27:59.162+0530 [initandlisten] connection accepted from 127.0.0.1:49282 #24 (24 connections now open)
2018-06-07T01:27:59.170+0530 [initandlisten] connection accepted from 127.0.0.1:49283 #25 (25 connections now open)
2018-06-07T01:27:59.176+0530 [initandlisten] connection accepted from 127.0.0.1:49284 #26 (26 connections now open)
2018-06-07T01:28:00.190+0530 [initandlisten] connection accepted from 127.0.0.1:49286 #27 (27 connections now open)
2018-06-07T01:28:00.201+0530 [initandlisten] connection accepted from 127.0.0.1:49287 #28 (28 connections now open)
2018-06-07T01:28:00.213+0530 [initandlisten] connection accepted from 127.0.0.1:49288 #29 (29 connections now open)
2018-06-07T01:28:00.218+0530 [initandlisten] connection accepted from 127.0.0.1:49289 #30 (30 connections now open)
2018-06-07T01:28:01.229+0530 [initandlisten] connection accepted from 127.0.0.1:49291 #31 (31 connections now open)
2018-06-07T01:28:01.237+0530 [initandlisten] connection accepted from 127.0.0.1:49292 #32 (32 connections now open)
2018-06-07T01:28:01.330+0530 [conn31] end connection 127.0.0.1:49291 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn16] end connection 127.0.0.1:49272 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn27] end connection 127.0.0.1:49286 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn15] end connection 127.0.0.1:49271 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn18] end connection 127.0.0.1:49274 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn14] end connection 127.0.0.1:49269 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn7] end connection 127.0.0.1:49255 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn17] end connection 127.0.0.1:49273 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn6] end connection 127.0.0.1:49254 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn20] end connection 127.0.0.1:49277 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn29] end connection 127.0.0.1:49288 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn21] end connection 127.0.0.1:49278 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn25] end connection 127.0.0.1:49283 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn2] end connection 127.0.0.1:49250 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn23] end connection 127.0.0.1:49281 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn24] end connection 127.0.0.1:49282 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn26] end connection 127.0.0.1:49284 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn32] end connection 127.0.0.1:49292 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn5] end connection 127.0.0.1:49253 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn30] end connection 127.0.0.1:49289 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn28] end connection 127.0.0.1:49287 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn19] end connection 127.0.0.1:49276 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn3] end connection 127.0.0.1:49251 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn4] end connection 127.0.0.1:49252 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn10] end connection 127.0.0.1:49260 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn11] end connection 127.0.0.1:49261 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn8] end connection 127.0.0.1:49258 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn22] end connection 127.0.0.1:49279 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn12] end connection 127.0.0.1:49262 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn13] end connection 127.0.0.1:49268 (31 connections now open)
2018-06-07T01:28:01.330+0530 [conn9] end connection 127.0.0.1:49259 (31 connections now open)
2018-06-07T01:28:43.604+0530 [clientcursormon] mem (MB) res:38 virt:4566
2018-06-07T01:28:43.604+0530 [clientcursormon]  mapped (incl journal view):320
2018-06-07T01:28:43.605+0530 [clientcursormon]  connections:1
2018-06-07T01:29:33.448+0530 [conn1] query mydb.system.namespaces planSummary: COLLSCAN ntoreturn:0 ntoskip:0 nscanned:3 nscannedObjects:3 keyUpdates:0 numYields:0 locks(micros) r:102236 nreturned:3 reslen:113 102ms
2018-06-07T01:33:43.651+0530 [clientcursormon] mem (MB) res:38 virt:4566
2018-06-07T01:33:43.651+0530 [clientcursormon]  mapped (incl journal view):320
2018-06-07T01:33:43.652+0530 [clientcursormon]  connections:1
2018-06-07T01:36:07.623+0530 [conn1] end connection 127.0.0.1:65352 (0 connections now open)
2018-06-07T01:37:18.911+0530 Ctrl-C signal
2018-06-07T01:37:18.911+0530 [consoleTerminate] got CTRL_C_EVENT, will terminate after current cmd ends
2018-06-07T01:37:19.013+0530 [consoleTerminate] now exiting
2018-06-07T01:37:19.020+0530 [consoleTerminate] dbexit:
2018-06-07T01:37:19.021+0530 [consoleTerminate] shutdown: going to close listening sockets...
2018-06-07T01:37:19.022+0530 [consoleTerminate] closing listening socket: 548
2018-06-07T01:37:19.023+0530 [consoleTerminate] shutdown: going to flush diaglog...
2018-06-07T01:37:19.025+0530 [consoleTerminate] shutdown: going to close sockets...
2018-06-07T01:37:19.027+0530 [consoleTerminate] shutdown: waiting for fs preallocator...
2018-06-07T01:37:19.027+0530 [consoleTerminate] shutdown: lock for final commit...
2018-06-07T01:37:19.028+0530 [consoleTerminate] shutdown: final commit...
2018-06-07T01:37:19.075+0530 [consoleTerminate] shutdown: closing all files...
2018-06-07T01:37:19.080+0530 [consoleTerminate] closeAllFiles() finished
2018-06-07T01:37:19.080+0530 [consoleTerminate] journalCleanup...
2018-06-07T01:37:19.132+0530 [consoleTerminate] removeJournalFiles
2018-06-07T01:37:19.138+0530 [consoleTerminate] shutdown: removing fs lock...
2018-06-07T01:37:19.138+0530 [consoleTerminate] dbexit: really exiting now

C:\Users\Pinakin Parkhe>

MONGODB CLIENT:

Microsoft Windows [Version 10.0.17134.48]
(c) 2018 Microsoft Corporation. All rights reserved.

C:\Users\Pinakin Parkhe>"C:\mongodb\mongodb-win\bin\mongo.exe"
MongoDB shell version: 2.6.3
connecting to: test
> show dbs
admin  (empty)
local  0.078GB
> show dbs
admin  (empty)
local  0.078GB
mydb   0.078GB
> use <mydb>
2018-06-07T01:29:13.959+0530 Error: [<mydb>] is not a valid database name at src/mongo/shell/mongo.js:41
> use mydb
switched to db mydb
> show collections
mycol
system.indexes
> db.mycol.find()
{ "_id" : ObjectId("5b183cc281613112904ae2a3"), "fifth" : " thinking..." }
{ "_id" : ObjectId("5b183cc281613112904ae2a1"), "second" : " thinking..." }
{ "_id" : ObjectId("5b183cc281613112904ae29d"), "third" : " thinking..." }
{ "_id" : ObjectId("5b183cc281613112904ae2a2"), "fourth" : " thinking..." }
{ "_id" : ObjectId("5b183cc281613112904ae29e"), "first" : " thinking..." }
{ "_id" : ObjectId("5b183cc481613112904ae2a5"), "second" : " eating..." }
{ "_id" : ObjectId("5b183cc581613112904ae2a7"), "second" : " done eating and now thinking..." }
{ "_id" : ObjectId("5b183cc581613112904ae2a9"), "first" : " eating..." }
{ "_id" : ObjectId("5b183cc681613112904ae2ab"), "first" : " done eating and now thinking..." }
{ "_id" : ObjectId("5b183cc681613112904ae2ad"), "fifth" : " eating..." }
{ "_id" : ObjectId("5b183cc781613112904ae2af"), "fifth" : " done eating and now thinking..." }
{ "_id" : ObjectId("5b183cc781613112904ae2b1"), "fourth" : " eating..." }
{ "_id" : ObjectId("5b183cc881613112904ae2b3"), "fourth" : " done eating and now thinking..." }
{ "_id" : ObjectId("5b183cc881613112904ae2b5"), "third" : " eating..." }
{ "_id" : ObjectId("5b183cc981613112904ae2b7"), "third" : " done eating and now thinking..." }
> db.system.indexes.find()
{ "v" : 1, "key" : { "_id" : 1 }, "name" : "_id_", "ns" : "mydb.mycol" }
> quit()

C:\Users\Pinakin Parkhe>

*/