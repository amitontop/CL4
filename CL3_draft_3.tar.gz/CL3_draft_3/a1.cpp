 /*
 Roll Number: 15U348
 Assignment Number: A-1
 */

#include <iostream>

using namespace std;
 
// A recursive binary search function. It returns location of x in
// given array arr[l..r] is present, otherwise -1
int binarySearch(int arr[], int l, int r, int x)
{
	if (r >= l)
   	{
        	int mid = l + (r - l)/2;
 
        	// If the element is present at the middle itself
        	if (arr[mid] == x)
			return mid;
 
        	// If element is smaller than mid, then it can only be present
        	// in left subarray
        	if (arr[mid] > x)
			return binarySearch(arr, l, mid-1, x);
 
	        // Else the element can only be present in right subarray
	        return binarySearch(arr, mid+1, r, x);
	}
 
	// We reach here when element is not present in array
	return -1;
}

void swap(int *xp, int *yp)
{
	int temp = *xp;
	*xp = *yp;
	*yp = temp;
}

void bubbleSort(int arr[], int n)
{
	int i, j;
	bool swapped;
	for(i = 0; i < n - 1; i++)
	{
		swapped = false;
		for(j = 0; j < n - i - 1; j++)
		{
			if(arr[j] > arr[j + 1])
			{
				swap(&arr[j], &arr[j + 1]);
				swapped = true;
			}
		}
		if(swapped == false)
			break;
	}
}

void printArray(int arr[], int size)
{
	for(int i = 0; i < size; i++)
		cout<<arr[i]<<"\t";
	cout<<"\n";
}
 
int main()
{
	int n,s;
	cout<<"\nPlease enter the number of elements: ";
	cin>>n;
   	int arr[n];
	cout<<"\nPlease enter the elements: \n";
	for(int i=0; i<n;i++)
		cin>>arr[i];
	cout<<"\nEntered elements are: \n";
	printArray(arr, n);
	cout<<"\nEntered elements in sorted order are: \n";
	bubbleSort(arr, n);
	printArray(arr, n);
	cout<<"\nPlease enter the element to be searched: ";
	cin>>s;
  	int result = binarySearch(arr, 0, n-1, s);
   	(result == -1)? cout<<"\nElement is not present in array.."
              	      : cout<<"\nElement is present at index "<<result<<".\n";
   	return 0;
}




/*

OUTPUT:

pinakinparkhe@ubuntu:~$ gedit a1.cpp
pinakinparkhe@ubuntu:~$ g++ a1.cpp
pinakinparkhe@ubuntu:~$ ./a.out

Please enter the number of elements: 5

Please enter the elements: 
5
4
6
2
7

Entered elements are: 
5	4	6	2	7	

Entered elements in sorted order are: 
2	4	5	6	7	

Please enter the element to be searched: 7

Element is present at index 4.
pinakinparkhe@ubuntu:~$ ./a.out

Please enter the number of elements: 6

Please enter the elements: 
2 4 3 1 5 6

Entered elements are: 
2	4	3	1	5	6	

Entered elements in sorted order are: 
1	2	3	4	5	6	

Please enter the element to be searched: 1

Element is present at index 0.
pinakinparkhe@ubuntu:~$ 

*/
